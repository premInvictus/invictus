import { TruncatetextPipe } from './truncatetext.pipe';

describe('TruncatetextPipe', () => {
  it('create an instance', () => {
    const pipe = new TruncatetextPipe();
    expect(pipe).toBeTruthy();
  });
});
