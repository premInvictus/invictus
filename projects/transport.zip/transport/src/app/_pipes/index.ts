export * from './capilalize.pipe';
export * from './dateformat.pipe';
export * from './zerodash.pipe';
export *  from './truncatetext.pipe';
export *  from './safe.pipe';
export *  from './number-to-word.pipe';
