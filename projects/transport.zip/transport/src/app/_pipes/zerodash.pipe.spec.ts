import { ZerodashPipe } from './zerodash.pipe';

describe('ZerodashPipe', () => {
  it('create an instance', () => {
    const pipe = new ZerodashPipe();
    expect(pipe).toBeTruthy();
  });
});
